import React from 'react';

class Tabs extends React.Component {

  constructor(props){
    super(props);
    this.state = {
      index: 0
    }
  }

  render(){
    return (
    <ul className="">
      {this.props.panes.map( pane => (
        <li key={pane.title+pane.content}> {pane.title}</li>
      ))}
      <br />


    </ul>
    {this.props.panes[this.state.index].content}
    )
  }





}

export default Tabs;
