import React from 'react';

class Clock extends React.Component {

  constructor(props){
    super(props);
    this.state = {
      time:  new Date()
    }
    this.tick = this.tick.bind(this);
  }


  tick(){
    //(prevState, props) => stateChange
    this.setState( {time: new Date()} )
  }



  componentDidMount() {
    this.intervalId = setInterval(this.tick, 1000);
  }

  componentWillUnmount(){
    clearInterval(this.intervalId);
  }



  render(){
    let secs = this.state.time.getSeconds();
    let mins = this.state.time.getMinutes();
    let hours = this.state.time.getHours();
    return (
      <h1 className="pacifico">The time is: {hours}:{mins}:{secs}</h1>


    )
  }
}

export default Clock;
